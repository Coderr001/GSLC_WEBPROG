
<h2 class="px-3 py-3">Catalog</h2>
<div style="display: flex">
@foreach($numberOfCard as $card)
    <div class="card mx-auto rounded" style="width: 18rem;">
        <img class="card-img-top" src="{{$card[1]}}" style="max-height : 160px; max-width : 650px;">
        <div class="card-body bg-dark rounded-bottom"">
        <p class="card-text text-white rounded-bottom">{{$card[0]}}</p>
        </div>
    </div>
@endforeach
</div>



