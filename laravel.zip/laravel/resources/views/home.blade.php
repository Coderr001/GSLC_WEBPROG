@extends('template')

@section('judul', 'Pet Shop')
@section('content', 'Best Pet Shop in Town')

