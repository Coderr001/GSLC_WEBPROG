
<h2 class="px-3 py-3">Catalog</h2>
<div style="display: flex">
<?php $__currentLoopData = $numberOfCard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mx-auto rounded" style="width: 18rem;">
        <img class="card-img-top" src="<?php echo e($card[1]); ?>" style="max-height : 160px; max-width : 650px;">
        <div class="card-body bg-dark rounded-bottom"">
        <p class="card-text text-white rounded-bottom"><?php echo e($card[0]); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php /**PATH C:\Users\micha\Downloads\2440094314- Aldo Alamsyah\Submission\project\laravel\resources\views/card.blade.php ENDPATH**/ ?>