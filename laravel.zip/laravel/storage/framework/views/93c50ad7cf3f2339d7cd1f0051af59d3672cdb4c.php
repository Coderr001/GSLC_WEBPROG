

<?php $__env->startSection('judul', 'Pet Shop'); ?>
<?php $__env->startSection('content', 'Best Pet Shop in Town'); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\micha\Downloads\2440094314- Aldo Alamsyah\Submission\project\laravel\resources\views/home.blade.php ENDPATH**/ ?>