

<?php $__env->startSection('judul', 'Pet Shop'); ?>
<?php $__env->startSection('content', 'Kami adalah bisnis ritel yang menjual berbagai jenis hewan. Toko hewan peliharaan juga menjual makanan hewan, persediaan, dan aksesoris. Berikut adalah hewan yang tersedia:'); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Gslc\laravel\resources\views/home.blade.php ENDPATH**/ ?>