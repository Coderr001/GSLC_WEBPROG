


<div style="display: flex">
<?php $__currentLoopData = $numberOfCard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="border: 1px red solid; width: 300px; padding: 20px">
        <div class="card-header" style="font-weight: bold; text-align: center"><?php echo e($card); ?></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php /**PATH D:\xampp\htdocs\Gslc\laravel\resources\views/card.blade.php ENDPATH**/ ?>