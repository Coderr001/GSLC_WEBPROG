@extends('template')

@section('judul', 'Pet Shop')
@section('content', 'Kami adalah bisnis ritel yang menjual berbagai jenis hewan. Toko hewan peliharaan juga menjual makanan hewan, persediaan, dan aksesoris. Berikut adalah hewan yang tersedia:')

